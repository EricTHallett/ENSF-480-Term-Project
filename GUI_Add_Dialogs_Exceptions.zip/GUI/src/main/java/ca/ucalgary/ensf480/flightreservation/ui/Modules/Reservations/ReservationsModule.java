package ca.ucalgary.ensf480.flightreservation.ui.Modules.Reservations;

import java.util.function.Consumer;
import ca.ucalgary.ensf480.flightreservation.ui.Modules.Module;
import ca.ucalgary.ensf480.flightreservation.database.DatabaseCallbacks;

public final class ReservationsModule implements Module {
    private final Object[][] actionButtons = {
        {"View Reservation", (Consumer<String[]>) this::viewReservation},
        {"Cancel Reservation", (Consumer<String[]>) this::cancelReservation},
        {"Remove Reservation", (Consumer<String[]>) this::removeReservation},
    };
    public String[] getSearchFields() {
        return new String[]{"Reservation ID","Customer ID","Flight ID"};
    }
    public Consumer<String[]> getSearchCallback() { return this::search; }
    public Object[][] getActionButtonArray() { return actionButtons; }
    public void search(String[] values) { DatabaseCallbacks.searchReservations(values); }
    public void viewReservation(String[] args) { DatabaseCallbacks.viewReservation(args); }
    public void cancelReservation(String[] args) { DatabaseCallbacks.cancelReservation(args); }
    public void removeReservation(String[] args) { DatabaseCallbacks.removeReservation(args); }




    //Data Base Callbacks go here
    public String[] getTableColumns() { return new String[]{"Reservation ID", "Customer ID", "Flight ID", "Status"}; }
    public Object[][] getTableData() {
        return DatabaseCallbacks.listReservations();
    }
    
}
