package ca.ucalgary.ensf480.flightreservation.ui.Navigation;

import java.util.function.Consumer;
import ca.ucalgary.ensf480.flightreservation.database.DatabaseCallbacks;
import ca.ucalgary.ensf480.flightreservation.ui.Modules.Module;
import ca.ucalgary.ensf480.flightreservation.ui.Modules.Flights.FlightsModule;
import ca.ucalgary.ensf480.flightreservation.ui.Modules.Reservations.ReservationsModule;
import ca.ucalgary.ensf480.flightreservation.ui.Modules.Customers.CustomersModule;

public final class UserNavigation implements Navigation {
    private final Consumer<Module> openModule;
    private final Runnable logout;

    public UserNavigation(Consumer<Module> openModule, Runnable logout) {
        this.openModule = openModule;
        this.logout = logout;
    }

    public Object[][] getButtons() {
        return new Object[][]{
            {"Flights", (Runnable) () -> openModule.accept(new FlightsModule())},
            {"Reservations", (Runnable) () -> openModule.accept(new ReservationsModule())},
            {"User Info", (Runnable) DatabaseCallbacks::viewUserInfo},
            {"Logout", logout},
        };
    }
}
